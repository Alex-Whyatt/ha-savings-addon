#!/bin/sh

# Start nginx in background
nginx -g "daemon off;" &

# Set database path to persistent storage
export DATABASE_PATH=/data/savings.db

# Start the Node.js backend
cd /app && npm start
